package com.ef.model.exceptions;

public class ArgumentParserException extends Exception {

    public ArgumentParserException(String message) {
        super(message);
    }
}
