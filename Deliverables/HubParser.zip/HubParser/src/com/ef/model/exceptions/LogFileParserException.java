package com.ef.model.exceptions;

public class LogFileParserException extends Exception {

    public LogFileParserException(String message) {
        super(message);
    }
}
